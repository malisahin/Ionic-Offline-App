Cordova-Bluetooth-Printer-Plugin
================================

Cordova Bluetooth Printer Plugin for android
